import { app } from "../../scripts/app.js";

app.registerExtension({
    name: "IXIWORKS.ControlNetPreprocessor",

    async beforeRegisterNodeDef(nodeType, nodeData, app) {
        if (nodeData.name !== "ControlNetPreprocessor") return;

        const origCreated = nodeType.prototype.onNodeCreated;
        nodeType.prototype.onNodeCreated = function () {
            if (origCreated) origCreated.apply(this, arguments);

            const self = this;
            const preprocessorWidget = this.widgets.find(
                (w) => w.name === "preprocessor"
            );
            if (!preprocessorWidget) return;

            const origCallback = preprocessorWidget.callback;
            preprocessorWidget.callback = function (value) {
                if (origCallback) origCallback.call(this, value);
                self._updateCannyWidgets(value);
            };

            this._updateCannyWidgets(preprocessorWidget.value);
        };

        nodeType.prototype._updateCannyWidgets = function (preprocessor) {
            const isCanny = preprocessor === "canny";
            for (const w of this.widgets) {
                if (w.name === "low_threshold" || w.name === "high_threshold") {
                    if (isCanny) {
                        w.type = "number";
                        w.computeSize = undefined;
                    } else {
                        w.type = "hidden";
                        w.computeSize = () => [0, -4];
                    }
                }
            }
            this.setSize(this.computeSize());
            app.graph.setDirtyCanvas(true, true);
        };

        const origOnConfigure = nodeType.prototype.onConfigure;
        nodeType.prototype.onConfigure = function (info) {
            if (origOnConfigure) origOnConfigure.apply(this, arguments);
            const preprocessorWidget = this.widgets && this.widgets.find(
                (w) => w.name === "preprocessor"
            );
            if (preprocessorWidget) {
                this._updateCannyWidgets(preprocessorWidget.value);
            }
        };
    },
});

app.registerExtension({
    name: "IXIWORKS.DiffSynthControlnetAdvanced",

    async beforeRegisterNodeDef(nodeType, nodeData, app) {
        if (nodeData.name !== "DiffSynthControlnetAdvanced") return;

        const origCreated = nodeType.prototype.onNodeCreated;
        nodeType.prototype.onNodeCreated = function () {
            if (origCreated) origCreated.apply(this, arguments);

            // Strength curve graph widget (always visible, interactive)
            this.widgets.push({
                name: "strength_graph",
                type: "custom",
                value: 0,
                options: { serialize: false },

                _getGraphParams: function (node, widgetWidth, y, h) {
                    const pad = 15;
                    const gx = pad;
                    const gy = y + 4;
                    const gw = (widgetWidth || node.size[0]) - pad * 2;
                    const gh = (h || 360) - 8;
                    const maxS = 2.0;

                    const val = (name, def) => {
                        const w = node.widgets.find((w) => w.name === name);
                        return w != null ? w.value : def;
                    };
                    const strengthStart = val("strength_start", 1.0);
                    const strengthEnd = val("strength_end", 0.0);
                    const startAt = val("start_at", 0.0);
                    const endAt = val("end_at", 1.0);

                    // s0 = strength at start_at, s1 = strength at end_at
                    const s0 = strengthStart;
                    const s1 = strengthEnd;

                    // Auto-detect fade direction
                    let fadeDir = "none";
                    if (strengthStart > strengthEnd) fadeDir = "fade out";
                    else if (strengthStart < strengthEnd) fadeDir = "fade in";

                    const sx = gx + startAt * gw;
                    const ex = gx + endAt * gw;
                    const toY = (v) => gy + gh - Math.min(v / maxS, 1.0) * gh;
                    const fromY = (py) => {
                        const raw = (gy + gh - py) / gh * maxS;
                        return Math.round(Math.max(0, Math.min(maxS, raw)) * 100) / 100;
                    };
                    const fromX = (px) => {
                        const raw = (px - gx) / gw;
                        return Math.round(Math.max(0, Math.min(1, raw)) * 100) / 100;
                    };

                    return {
                        gx, gy, gw, gh, maxS,
                        strengthStart, strengthEnd, startAt, endAt, fadeDir,
                        s0, s1, sx, ex, toY, fromY, fromX, val,
                    };
                },

                draw: function (ctx, node, widgetWidth, y, h) {
                    const p = this._getGraphParams(node, widgetWidth, y, h);
                    node._graphWidgetY = y;
                    node._graphWidgetH = h;

                    ctx.save();

                    // Background
                    ctx.fillStyle = "#1a1a2e";
                    ctx.beginPath();
                    ctx.roundRect(p.gx, p.gy, p.gw, p.gh, 4);
                    ctx.fill();
                    ctx.clip();

                    // Subtle grid lines
                    ctx.strokeStyle = "rgba(255,255,255,0.05)";
                    ctx.lineWidth = 1;
                    for (let i = 1; i < 4; i++) {
                        const ly = p.gy + (p.gh / 4) * i;
                        ctx.beginPath();
                        ctx.moveTo(p.gx, ly);
                        ctx.lineTo(p.gx + p.gw, ly);
                        ctx.stroke();
                    }

                    // Y-axis labels (strength_start / strength_end)
                    ctx.font = "9px monospace";
                    ctx.fillStyle = "rgba(255,255,255,0.4)";
                    ctx.textAlign = "left";
                    const highVal = Math.max(p.strengthStart, p.strengthEnd);
                    const lowVal = Math.min(p.strengthStart, p.strengthEnd);
                    ctx.fillText(highVal.toFixed(2), p.gx + 4, p.gy + 12);
                    ctx.fillText(lowVal.toFixed(2), p.gx + 4, p.gy + p.gh - 4);

                    // Fill under curve
                    ctx.fillStyle = "rgba(179,157,219,0.2)";
                    ctx.beginPath();
                    ctx.moveTo(p.sx, p.gy + p.gh);
                    ctx.lineTo(p.sx, p.toY(p.s0));
                    ctx.lineTo(p.ex, p.toY(p.s1));
                    ctx.lineTo(p.ex, p.gy + p.gh);
                    ctx.closePath();
                    ctx.fill();

                    // Strength line
                    ctx.strokeStyle = "#B39DDB";
                    ctx.lineWidth = 2;
                    ctx.beginPath();
                    ctx.moveTo(p.sx, p.toY(p.s0));
                    ctx.lineTo(p.ex, p.toY(p.s1));
                    ctx.stroke();

                    // Start/end dashed markers
                    ctx.lineWidth = 1;
                    ctx.setLineDash([3, 3]);
                    if (p.startAt > 0.01) {
                        ctx.strokeStyle = node._graphDrag === "start"
                            ? "rgba(255,255,255,0.6)"
                            : "rgba(255,255,255,0.2)";
                        ctx.beginPath();
                        ctx.moveTo(p.sx, p.gy);
                        ctx.lineTo(p.sx, p.gy + p.gh);
                        ctx.stroke();
                    }
                    if (p.endAt < 0.99) {
                        ctx.strokeStyle = node._graphDrag === "end"
                            ? "rgba(255,255,255,0.6)"
                            : "rgba(255,255,255,0.2)";
                        ctx.beginPath();
                        ctx.moveTo(p.ex, p.gy);
                        ctx.lineTo(p.ex, p.gy + p.gh);
                        ctx.stroke();
                    }
                    ctx.setLineDash([]);

                    // Endpoint dots (larger when dragging)
                    ctx.fillStyle = "#B39DDB";
                    const r0 = node._graphDrag === "s0" ? 6 : 4;
                    ctx.beginPath();
                    ctx.arc(p.sx, p.toY(p.s0), r0, 0, Math.PI * 2);
                    ctx.fill();
                    const r1 = node._graphDrag === "s1" ? 6 : 4;
                    ctx.beginPath();
                    ctx.arc(p.ex, p.toY(p.s1), r1, 0, Math.PI * 2);
                    ctx.fill();

                    // Fade direction indicator (auto-detected)
                    if (p.fadeDir !== "none") {
                        ctx.font = "10px monospace";
                        ctx.fillStyle = "rgba(179,157,219,0.7)";
                        ctx.textAlign = "center";
                        const midX = (p.sx + p.ex) / 2;
                        const arrow = p.fadeDir === "fade out" ? "▼" : "▲";
                        ctx.fillText(arrow, midX, p.gy + p.gh / 2);
                    }

                    ctx.restore();
                },

                mouse: function (event, pos, node) {
                    if (node._graphWidgetY == null) return false;

                    const p = this._getGraphParams(
                        node, node.size[0],
                        node._graphWidgetY, node._graphWidgetH
                    );
                    const [mx, my] = pos;
                    const hitR = 10;

                    const setVal = (name, v) => {
                        const w = node.widgets.find((w) => w.name === name);
                        if (w) { w.value = v; if (w.callback) w.callback(v); }
                    };

                    const etype = event.type;

                    if (etype === "pointerdown" || etype === "mousedown") {
                        // Hit test: dots first, then markers
                        if (Math.hypot(mx - p.sx, my - p.toY(p.s0)) < hitR) {
                            node._graphDrag = "s0"; return true;
                        }
                        if (Math.hypot(mx - p.ex, my - p.toY(p.s1)) < hitR) {
                            node._graphDrag = "s1"; return true;
                        }
                        if (Math.abs(mx - p.sx) < hitR && my >= p.gy && my <= p.gy + p.gh) {
                            node._graphDrag = "start"; return true;
                        }
                        if (Math.abs(mx - p.ex) < hitR && my >= p.gy && my <= p.gy + p.gh) {
                            node._graphDrag = "end"; return true;
                        }
                        return false;
                    }

                    if ((etype === "pointermove" || etype === "mousemove") && node._graphDrag) {
                        const drag = node._graphDrag;
                        if (drag === "s0") {
                            setVal("strength_start", p.fromY(my));
                        } else if (drag === "s1") {
                            setVal("strength_end", p.fromY(my));
                        } else if (drag === "start") {
                            setVal("start_at", Math.min(p.fromX(mx), p.val("end_at", 1)));
                        } else if (drag === "end") {
                            setVal("end_at", Math.max(p.fromX(mx), p.val("start_at", 0)));
                        }
                        app.graph.setDirtyCanvas(true, true);
                        return true;
                    }

                    if (etype === "pointerup" || etype === "mouseup") {
                        if (node._graphDrag) {
                            node._graphDrag = null;
                            return true;
                        }
                    }

                    return false;
                },

                computeSize: function () {
                    return [0, 360];
                },
            });

            this.setSize(this.computeSize());
        };
    },
});
