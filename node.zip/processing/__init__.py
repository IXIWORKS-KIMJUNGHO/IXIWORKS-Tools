"""
Video processing package
"""

from .video_processor import VideoProcessor

__all__ = ['VideoProcessor']
